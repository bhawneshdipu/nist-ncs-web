<?php
error_reporting(E_ALL);
ini_set("display_errors", 1);
$user = 'dipu';
$host = 'localhost';
$pass = 'dipu';
$database = 'dipu';
$serError = "Unable to connect to the Server.";
$conn = mysqli_connect($host,$user,$pass,$database);
if(!$conn){
     echo 'Error connect to mysql Database'.mysqli_connect_error();

 }else{
     echo 'connected to mysql database '.$database;
 }
function clean($str) {
        $str = stripslashes($str);

    return mysqli_real_escape_string($str);
}
/*mysqli_error($conn)."  ".mysqli_sqlstate($conn).*/
?>