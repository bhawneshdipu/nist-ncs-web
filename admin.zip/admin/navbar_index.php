<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation" >


    <div class="container">
        <!-- Logo and responsive toggle -->


        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            </button>
            <a class="navbar-brand nav navbar-nav navbar-left" href="./index.php"><img src="./../images/nist.jpg" width="150px" height="35px"  vspace="0px" class="img-circle" ></a>
        </div>
        <!-- Navbar links -->
        <div class="collapse navbar-collapse" id="navbar">
            <ul class="nav navbar-nav">
                <li class="active">
                    <a href="./index.php"><b>Home</b></a>
                </li>
                </ul>



        </div>
        <!-- /.navbar-collapse -->
    </div>
    <!-- /.container -->
</nav>
