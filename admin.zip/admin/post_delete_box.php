<div class="panel panel-danger">
    <div class="panel-heading">
        <div class="panel-title">Delete Post </div>
        <div class="panel-body">
            <form id="delete_post" action="./delete_post.php" method="post">
                <input type="number" value="" placeholder="Enter Post ID " name="post_id" id="post_id">
                <input type="submit" value="Delete" class="btn btn-default btn-danger" formaction="./delete_post.php" name="delete_post">
            </form>
        </div>
    </div>
</div>