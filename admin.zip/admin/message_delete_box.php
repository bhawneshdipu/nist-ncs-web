<div class="panel panel-danger">
    <div class="panel-heading">
        <div class="panel-title">Delete Message </div>
        <div class="panel-body">
            <form id="delete_message" action="./delete_msg.php" method="post">
            <input type="number" value="" placeholder="Enter Message ID " name="message_id" id="message_id">
            <input type="submit" value="Delete" class="btn btn-default btn-danger" formaction="./delete_msg.php" name="delete_msg">
            </form>
        </div>
    </div>
</div>